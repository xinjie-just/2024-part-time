export declare const DEFAULT_COLOR = "#001F97";
export declare const DEFAULT_SYSTEM_SWATCH_COLORS: string[];
export declare const SATURATION_PANEL_DEFAULT_WIDTH = 343;
export declare const SATURATION_PANEL_DEFAULT_HEIGHT = 144;
export declare const SLIDER_DEFAULT_WIDTH = 303;
export declare const HUE_MAX = 360;
export declare const ALPHA_MAX = 100;
