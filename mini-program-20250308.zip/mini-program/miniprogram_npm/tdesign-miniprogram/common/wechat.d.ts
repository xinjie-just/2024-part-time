export declare const getObserver: (context: any, selector: string) => Promise<unknown>;
