import { TdActionSheetProps } from './type';
declare const props: TdActionSheetProps;
export default props;
