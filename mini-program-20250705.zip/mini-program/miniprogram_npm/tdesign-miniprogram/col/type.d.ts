export interface TdColProps {
    offset?: {
        type: null;
        value?: string | number;
    };
    span?: {
        type: null;
        value?: string | number;
    };
}
