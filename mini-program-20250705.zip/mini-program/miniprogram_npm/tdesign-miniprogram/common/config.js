export default {
    prefix: "t",
};
export const prefix = "t";
